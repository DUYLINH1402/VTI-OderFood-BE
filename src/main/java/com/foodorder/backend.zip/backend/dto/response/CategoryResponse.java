package com.foodorder.backend.dto.response;
import lombok.Data;

@Data
public class CategoryResponse {
    private Long id;
    private String name;
}
